<?php
$info=array(
	'name' => 'rotator-settings',
	'pagename' => 'rotator-options',
	'title' => 'Slider manager',
	'slider_name' => 'ansimuz_slider',
	'image_name' => 'ansimuz_slider_images',
	'link_name' => 'ansimuz_slider_links',
	'desc_name' => 'ansimuz_slider_desc',
	'title_name' => 'ansimuz_slider_title'
);



$sliderpage=new ansimuz_slider_page($info);