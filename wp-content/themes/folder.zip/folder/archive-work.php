<?php 
/*
* Archives for work
*
*/
?>

<?php get_header() ?>
	
	<?php get_template_part('includes/content-work') ?>
	
<?php get_footer() ?>