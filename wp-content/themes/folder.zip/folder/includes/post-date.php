<?php
	/*
	* Date include on all the posts
	*
	*/
?>
<div class="entry-date">
	<div class="number"><?php the_time('d') ?></div><div class="month"><?php the_time('M') ?></div>
</div>